package debtbuddies.GameServer.DeckLibrary;

public enum Suit {
    HEARTS,
    DIAMONDS,
    CLUBS,
    SPADES
}
