package debtbuddies.GameServer.Games.TexasHoldEm.TexasHoldEmInfo;

import debtbuddies.GameServer.DeckLibrary.Card;

import java.util.List;

public class StageInfo {

    List<Card> pit;

    public StageInfo(List<Card> pit){
        this.pit = pit;
    }

}
