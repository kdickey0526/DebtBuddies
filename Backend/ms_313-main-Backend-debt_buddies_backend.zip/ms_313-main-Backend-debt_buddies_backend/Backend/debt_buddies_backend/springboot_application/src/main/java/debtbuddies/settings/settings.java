package debtbuddies.settingss;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.*;

/**
 *
 * @author Vivek Bengre
 *
 */

@Entity
public class settings {

    /*
     * The annotation @ID marks the field below as the primary key for the table created by springboot
     * The @GeneratedValue generates a value if not already present, The strategy in this case is to start from 1 and increment for each table
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String settingsName;
    private boolean isOnline;
    private String Theme;
    private String cardTheme;
    private int MasterVolume;
    private String icon;

    /*
     * @OneToOne creates a relation between the current entity/table(Laptop) with the entity/table defined below it(settings)
     * cascade is responsible propagating all changes, even to children of the class Eg: changes made to laptop within a settings object will be reflected
     * in the database (more info : https://www.baeldung.com/jpa-cascade-types)
     * @JoinColumn defines the ownership of the foreign key i.e. the settings table will have a field called laptop_id
     */

    /*@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "laptop_id")
    private Laptop laptop;*/

    public settings(String settingsName, String Theme, String cardTheme) {
        this.settingsName = settingsName;
        this.MasterVolume = 0;
        this.Theme = Theme;
        this.cardTheme = cardTheme;
        this.isOnline = true;
        this.icon = "icon0";
    }

    public settings() {
    }

    // =============================== Getters and Setters for each field ================================== //

    public String convert_hex(String input) {

        try {
            // Create a SHA-256 message digest object
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Update the digest with the input string bytes
            byte[] hash = digest.digest(input.getBytes());

            // Convert the byte array to a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            System.out.println("SHA-256 Hash: " + hexString.toString());
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();

        }
        return "";
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getsettingsName(){
        return settingsName;
    }

    public void setsettingsName(String settingsName){
        this.settingsName = settingsName;
    }
    public String getIcon(){
        return icon;
    }

    public void setIcon(String icon){
        this.icon = icon;
    }
    public int getMasterVolume(){
        return MasterVolume;
    }

    public void setMasterVolume(int MasterVolume){
        this.MasterVolume = MasterVolume;
    }

    public Boolean getIsOnline(){
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline){
        this.isOnline = isOnline;
    }
    public String getTheme(){
        return Theme;
    }
    public void setTheme(String Theme){
        this.Theme = Theme;
    }
    public String getcardTheme(){
        return cardTheme;
    }
    public void setcardTheme(String cardTheme){
        this.cardTheme = convert_hex(cardTheme);
    }

    /*public Laptop getLaptop(){
        return laptop;
    }

    public void setLaptop(Laptop laptop){
        this.laptop = laptop;
    }*/

}
