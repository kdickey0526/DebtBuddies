package debtbuddies.games;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Vivek Bengre
 *
 */

@Entity
public class games {

     /*
     * The annotation @ID marks the field below as the primary key for the table created by springboot
     * The @GeneratedValue generates a value if not already present, The strategy in this case is to start from 1 and increment for each table
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int highestTexasScore;
    private boolean isOnline;
    private int WhackScore;
    private int WarLost;
    private int WarWon;

    /*
     * @OneToOne creates a relation between the current entity/table(Laptop) with the entity/table defined below it(User)
     * cascade is responsible propagating all changes, even to children of the class Eg: changes made to laptop within a user object will be reflected
     * in the database (more info : https://www.baeldung.com/jpa-cascade-types)
     * @JoinColumn defines the ownership of the foreign key i.e. the user table will have a field called laptop_id
     */

    /*@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "laptop_id")
    private Laptop laptop;*/

    public games(int highestTexasScore, int email, int WhackScore) {
        this.highestTexasScore = highestTexasScore;
        this.WarLost = 0;
        this.WhackScore = WhackScore;
        this.isOnline = true;
        this.WarWon = 0;
    }

    public games() {
    }

    // =============================== Getters and Setters for each field ================================== //

    public String convert_hex(String input) {

        try {
            // Create a SHA-256 message digest object
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Update the digest with the input int bytes
            byte[] hash = digest.digest(input.getBytes());

            // Convert the byte array to a hexadecimal int
            StringBuilder hexint = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexint.append('0');
                hexint.append(hex);
            }

            System.out.println("SHA-256 Hash: " + hexint.toString());
            return hexint.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();

        }
        return "";
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public int gethighestTexasScore(){
        return highestTexasScore;
    }

    public void sethighestTexasScore(int highestTexasScore){
        this.highestTexasScore = highestTexasScore;
    }
    public int getWarWon(){
        return WarWon;
    }

    public void setWarWon(int WarWon){
        this.WarWon = WarWon;
    }
    public int getWarLost(){
        return WarLost;
    }

    public void setWarLost(int WarLost){
        this.WarLost = WarLost;
    }

    public Boolean getIsOnline(){
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline){
        this.isOnline = isOnline;
    }
    public int getWhackScore(){
        return WhackScore;
    }
    public void setWhackScore(int WhackScore){
        this.WhackScore = convert_hex(WhackScore);
    }

    /*public Laptop getLaptop(){
        return laptop;
    }

    public void setLaptop(Laptop laptop){
        this.laptop = laptop;
    }*/

}
